// Переключение между гипотезами
document.querySelectorAll('.hypothesis-item').forEach((item, index) => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.hypo-section').forEach(section =>
      section.classList.add('hidden')
    );
    const targetSection = document.getElementById(`section${index + 1}`);
    if (targetSection) {
      targetSection.classList.remove('hidden');
      window.scrollTo({ top: targetSection.offsetTop - 80, behavior: 'smooth' });
    }
  });
});

// Инициализация Leaflet карты
const map = L.map('windMap').setView([54.5, 10], 5);

// Англоязычные тайлы от Carto
L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
  attribution: '&copy; <a href="https://carto.com/">CARTO</a> &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
  subdomains: 'abcd',
  maxZoom: 19
}).addTo(map);

// Данные по странам
const infoData = {
 "United Kingdom": "1. Total turbines: ~11,500 (Onshore: ~8,000, Offshore: ~3,500)\n2. Annual production: ~85 billion kWh, covering ~25% of the UK's total electricity demand\n3. Wind energy revenue: ~£8–10 billion/year\n4. Exports: Yes — exports around 20–25 TWh of electricity per year (via interconnectors)\n5. Average wind speed in best regions: 9–11 m/s"
,
 Germany: "1. Total turbines: ~28,500 (Onshore: ~26,800, Offshore: ~1,700)\n2. Annual production: ~139 billion kWh, covering 28–29% of national electricity demand\n3. Wind energy revenue: €11–13 billion/year\n4. Exports ~60 TWh of electricity annually\n5. Average wind speed in best regions: 8.5–9.5 m/s"
,
 Denmark: "1. Total turbines: ~6,700 (Onshore: ~4,300, Offshore: ~2,400)\n2. Annual production: ~45 billion kWh, covering ~50% of national electricity demand\n3. Wind energy revenue: ~€3–4 billion/year\n4. Exports: Yes — exports ~10–12 TWh of electricity per year\n5. Average wind speed in best regions: 8.5–10 m/s"
,
  Netherlands: "1. Total turbines: ~3,200 (Onshore: ~2,200, Offshore: ~1,000)\n2. Annual production: ~28 billion kWh, covering ~15–17% of national electricity demand\n3. Wind energy revenue: ~€2–3 billion/year\n4. Exports: Yes — exports ~5–7 TWh of electricity annually (mainly via Germany & Belgium interconnectors)\n5. Average wind speed in best regions: 8.0–9.5 m/s"
,
 Spain: "1. Total turbines: ~21,500 (Onshore: ~21,300, Offshore: ~200 — in pilot phase)\n2. Annual production: ~63 billion kWh, covering ~23–24% of national electricity demand\n3. Wind energy revenue: ~€5–6 billion/year\n4. Exports: Yes — exports ~10–12 TWh of electricity annually (mainly to France and Portugal)\n5. Average wind speed in best regions: 7.5–9.0 m/s"
,
 France: "1. Total turbines: ~9,400 (Onshore: ~9,000, Offshore: ~400 — early-stage development)\n2. Annual production: ~42 billion kWh, covering ~9–10% of national electricity demand\n3. Wind energy revenue: ~€3–4 billion/year\n4. Exports: Yes — exports ~15–20 TWh of electricity annually (mainly to Spain, Italy, Germany)\n5. Average wind speed in best regions: 7.0–8.5 m/s"
,
  Sweden: "1. Total turbines: ~4,900 (Onshore: ~4,300, Offshore: ~600)\n2. Annual production: ~33 billion kWh, covering ~20–22% of national electricity demand\n3. Wind energy revenue: €2–2.5 billion/year\n4. Exports: ~25–30 TWh of electricity annually (mainly to Finland, Denmark, Germany)\n5. Average wind speed in best regions: 7.5–9.0 m/s"
,
Poland: "1. Total turbines: ~1,400 (Onshore: ~1,390, Offshore: ~10 — pre-development stage)\n2. Annual production: ~17 billion kWh, covering ~9–10% of national electricity demand\n3. Wind energy revenue: ~€1.2–1.5 billion/year\n4. Exports: Yes — small surplus exported to Germany, Czechia, Slovakia\n5. Average wind speed in best regions: 7.0–8.5 m/s",
Albania: "1. Total turbines: ~90 (Onshore: ~90, Offshore: 0 — no current offshore development)\n2. Annual production: ~0.2 billion kWh, covering ~0.5–1% of national electricity demand\n3. Wind energy revenue: ~€10–15 million/year\n4. Exports: No — Albania is a net importer of electricity\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Austria: "1. Total turbines: ~1,400 (Onshore: ~1,400, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~3.5 billion kWh, covering ~6–7% of national electricity demand\n3. Wind energy revenue: ~€300–400 million/year\n4. Exports: Yes — Austria exports a small amount of surplus electricity in peak production periods\n5. Average wind speed in best regions: 6.5–7.5 m/s",
Belgium: "1. Total turbines: ~1,800 (Onshore: ~1,200, Offshore: ~600)\n2. Annual production: ~11 billion kWh, covering ~10–11% of national electricity demand\n3. Wind energy revenue: ~€800 million–1 billion/year\n4. Exports: Yes — Belgium exports surplus electricity, especially from offshore wind, mainly to the Netherlands and France\n5. Average wind speed in best regions: 7.5–9.0 m/s",
"Bosnia and Herzegovina": "1. Total turbines: ~80 (Onshore: ~80, Offshore: 0 — no offshore projects)\n2. Annual production: ~0.15 billion kWh, covering ~1–2% of national electricity demand\n3. Wind energy revenue: ~€8–12 million/year\n4. Exports: No — electricity imports still exceed exports overall\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Croatia: "1. Total turbines: ~200 (Onshore: ~200, Offshore: 0 — no current offshore projects)\n2. Annual production: ~0.5 billion kWh, covering ~3–4% of national electricity demand\n3. Wind energy revenue: ~€30–40 million/year\n4. Exports: Yes — Croatia exports small amounts of electricity during peak wind production\n5. Average wind speed in best regions: 7.0–9.0 m/s",
"Czech Republic": "1. Total turbines: ~200 (Onshore: ~200, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.3 billion kWh, covering ~1–2% of national electricity demand\n3. Wind energy revenue: ~€20–25 million/year\n4. Exports: Yes — Czech Republic exports electricity, though wind contributes only a small share\n5. Average wind speed in best regions: 6.0–7.5 m/s",
Estonia: "1. Total turbines: ~130 (Onshore: ~130, Offshore: 0 — offshore projects in early planning)\n2. Annual production: ~0.4 billion kWh, covering ~5–6% of national electricity demand\n3. Wind energy revenue: ~€25–30 million/year\n4. Exports: Yes — Estonia exports electricity to Latvia and Finland, but wind’s share is small\n5. Average wind speed in best regions: 7.5–9.0 m/s",
Finland: "1. Total turbines: ~1,500 (Onshore: ~1,470, Offshore: ~30 — small-scale offshore development)\n2. Annual production: ~12 billion kWh, covering ~14–15% of national electricity demand\n3. Wind energy revenue: ~€900 million–1.1 billion/year\n4. Exports: Yes — Finland exports electricity, especially to Estonia and Sweden, including wind-based surplus\n5. Average wind speed in best regions: 7.0–9.0 m/s",
Georgia: "1. Total turbines: ~20 (Onshore: ~20, Offshore: 0 — no offshore potential)\n2. Annual production: ~0.05 billion kWh, covering <1% of national electricity demand\n3. Wind energy revenue: ~€3–5 million/year\n4. Exports: Yes — Georgia exports electricity, mostly from hydro, wind share is minimal\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Greece: "1. Total turbines: ~2,800 (Onshore: ~2,700, Offshore: ~100 — early-stage offshore development)\n2. Annual production: ~9 billion kWh, covering ~15–17% of national electricity demand\n3. Wind energy revenue: ~€600–750 million/year\n4. Exports: Yes — Greece exports some electricity during peak production, mainly to Balkan neighbors\n5. Average wind speed in best regions: 7.5–9.5 m/s",
Hungary: "1. Total turbines: ~170 (Onshore: ~170, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.25 billion kWh, covering ~1–2% of national electricity demand\n3. Wind energy revenue: ~€15–20 million/year\n4. Exports: Yes — Hungary exports electricity, but wind contributes minimally\n5. Average wind speed in best regions: 6.0–7.0 m/s",
Iceland: "1. Total turbines: ~10 (Onshore: ~10, Offshore: 0 — no offshore development)\n2. Annual production: ~0.02 billion kWh, covering <0.1% of national electricity demand\n3. Wind energy revenue: ~€1–2 million/year\n4. Exports: No — Iceland does not export electricity (isolated grid)\n5. Average wind speed in best regions: 9.0–10.0 m/s",
Ireland: "1. Total turbines: ~2,000 (Onshore: ~1,950, Offshore: ~50 — offshore expansion underway)\n2. Annual production: ~10 billion kWh, covering ~35–40% of national electricity demand\n3. Wind energy revenue: ~€800 million–1 billion/year\n4. Exports: Yes — Ireland exports electricity to the UK via interconnectors\n5. Average wind speed in best regions: 8.5–10.0 m/s",
Italy: "1. Total turbines: ~1,250 (Onshore: ~1,200, Offshore: ~50 — early-stage offshore projects)\n2. Annual production: ~20 billion kWh, covering ~7–8% of national electricity demand\n3. Wind energy revenue: ~€1.5–2 billion/year\n4. Exports: Yes — Italy exports electricity during peak production, mainly to Switzerland and France\n5. Average wind speed in best regions: 6.5–8.5 m/s",
Latvia: "1. Total turbines: ~120 (Onshore: ~120, Offshore: 0 — offshore projects in planning)\n2. Annual production: ~0.2 billion kWh, covering ~2–3% of national electricity demand\n3. Wind energy revenue: ~€10–15 million/year\n4. Exports: Yes — Latvia exports electricity to Estonia and Lithuania, but wind share is small\n5. Average wind speed in best regions: 7.0–8.5 m/s",
Lithuania: "1. Total turbines: ~170 (Onshore: ~170, Offshore: 0 — offshore projects under development)\n2. Annual production: ~0.5 billion kWh, covering ~6–7% of national electricity demand\n3. Wind energy revenue: ~€30–40 million/year\n4. Exports: Yes — Lithuania exports electricity, including wind-based surplus, mainly to Latvia and Poland\n5. Average wind speed in best regions: 7.0–8.5 m/s",
Luxembourg: "1. Total turbines: ~70 (Onshore: ~70, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.15 billion kWh, covering ~2–3% of national electricity demand\n3. Wind energy revenue: ~€8–10 million/year\n4. Exports: No — Luxembourg is a net importer of electricity\n5. Average wind speed in best regions: 6.5–7.5 m/s",
"North Macedonia": "1. Total turbines: ~40 (Onshore: ~40, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.07 billion kWh, covering ~1–2% of national electricity demand\n3. Wind energy revenue: ~€4–6 million/year\n4. Exports: No — North Macedonia is a net importer of electricity\n5. Average wind speed in best regions: 6.5–7.5 m/s",
Montenegro: "1. Total turbines: ~40 (Onshore: ~40, Offshore: 0 — no offshore development)\n2. Annual production: ~0.1 billion kWh, covering ~2–3% of national electricity demand\n3. Wind energy revenue: ~€5–7 million/year\n4. Exports: Yes — Montenegro exports electricity during surplus periods, mostly from hydro, wind share is small\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Portugal: "1. Total turbines: ~2,800 (Onshore: ~2,750, Offshore: ~50 — pilot offshore projects underway)\n2. Annual production: ~15 billion kWh, covering ~25–28% of national electricity demand\n3. Wind energy revenue: ~€1.2–1.4 billion/year\n4. Exports: Yes — Portugal exports electricity, mainly to Spain, especially during wind surpluses\n5. Average wind speed in best regions: 7.5–9.0 m/s",
Romania: "1. Total turbines: ~1,200 (Onshore: ~1,200, Offshore: 0 — offshore projects planned in Black Sea)\n2. Annual production: ~7 billion kWh, covering ~12–13% of national electricity demand\n3. Wind energy revenue: ~€500–600 million/year\n4. Exports: Yes — Romania exports electricity, especially to Hungary, Bulgaria, and Serbia\n5. Average wind speed in best regions: 7.5–9.0 m/s",
Russia: "1. Total turbines: ~250 (Onshore: ~250, Offshore: 0 — offshore potential exists but not developed)\n2. Annual production: ~0.5 billion kWh, covering <0.1% of national electricity demand\n3. Wind energy revenue: ~€30–40 million/year\n4. Exports: Yes — Russia exports large volumes of electricity, but wind’s share is negligible\n5. Average wind speed in best regions: 7.5–9.5 m/s",
"San Marino": "1. Total turbines: 0 (Onshore: 0, Offshore: 0 — no wind installations)\n2. Annual production: 0 kWh from wind, 0% of national electricity demand\n3. Wind energy revenue: €0/year\n4. Exports: No — San Marino imports nearly all of its electricity from Italy\n5. Average wind speed in best regions: 6.0–7.0 m/s",
Serbia: "1. Total turbines: ~100 (Onshore: ~100, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.3 billion kWh, covering ~1–2% of national electricity demand\n3. Wind energy revenue: ~€20–25 million/year\n4. Exports: Yes — Serbia exports electricity, mainly from hydro and thermal sources; wind share is minimal\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Slovakia: "1. Total turbines: ~5 (Onshore: ~5, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.01 billion kWh, covering <0.1% of national electricity demand\n3. Wind energy revenue: ~€0.5–1 million/year\n4. Exports: Yes — Slovakia exports electricity, but wind contribution is negligible\n5. Average wind speed in best regions: 6.0–7.0 m/s",
Slovenia: "1. Total turbines: ~2 (Onshore: ~2, Offshore: 0 — small coastline, no offshore development)\n2. Annual production: ~0.005 billion kWh, covering <0.1% of national electricity demand\n3. Wind energy revenue: ~€0.2–0.3 million/year\n4. Exports: Yes — Slovenia exports electricity, mainly from hydro and nuclear sources; wind share is negligible\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Switzerland: "1. Total turbines: ~40 (Onshore: ~40, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.1 billion kWh, covering ~0.2–0.3% of national electricity demand\n3. Wind energy revenue: ~€5–7 million/year\n4. Exports: Yes — Switzerland exports electricity, mainly from hydro and nuclear; wind share is minimal\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Cyprus: "1. Total turbines: ~40 (Onshore: ~40, Offshore: 0 — offshore potential under consideration)\n2. Annual production: ~0.25 billion kWh, covering ~5–6% of national electricity demand\n3. Wind energy revenue: ~€15–20 million/year\n4. Exports: No — Cyprus has an isolated grid and does not export electricity\n5. Average wind speed in best regions: 7.0–8.5 m/s",
Ukraine: "1. Total turbines: ~750 (Onshore: ~750, Offshore: 0 — offshore projects planned in Black Sea)\n2. Annual production: ~2.5 billion kWh, covering ~2–3% of national electricity demand\n3. Wind energy revenue: ~€150–200 million/year\n4. Exports: Yes — Ukraine exports electricity to EU neighbors; wind share is growing but still small\n5. Average wind speed in best regions: 7.5–9.0 m/s",
Andorra: "1. Total turbines: 0 (Onshore: 0, Offshore: 0 — landlocked, no installations)\n2. Annual production: 0 kWh from wind, 0% of national electricity demand\n3. Wind energy revenue: €0/year\n4. Exports: No — Andorra imports nearly all electricity from France and Spain\n5. Average wind speed in best regions: 6.0–7.0 m/s",
Armenia: "1. Total turbines: ~5 (Onshore: ~5, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.01 billion kWh, covering <0.1% of national electricity demand\n3. Wind energy revenue: ~€0.5–1 million/year\n4. Exports: Yes — Armenia exports limited electricity, mainly from nuclear and hydro sources\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Liechtenstein: "1. Total turbines: 0 (Onshore: 0, Offshore: 0 — landlocked, no wind installations)\n2. Annual production: 0 kWh from wind, 0% of national electricity demand\n3. Wind energy revenue: €0/year\n4. Exports: No — Liechtenstein imports nearly all electricity, mainly from Switzerland and Austria\n5. Average wind speed in best regions: 6.0–7.0 m/s",
Kosovo: "1. Total turbines: ~30 (Onshore: ~30, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.05 billion kWh, covering ~1% of national electricity demand\n3. Wind energy revenue: ~€2–3 million/year\n4. Exports: No — Kosovo is mostly reliant on domestic coal and imports electricity during shortages\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Monaco: "1. Total turbines: 0 (Onshore: 0, Offshore: 0 — no wind installations)\n2. Annual production: 0 kWh from wind, 0% of national electricity demand\n3. Wind energy revenue: €0/year\n4. Exports: No — Monaco imports nearly all electricity from France\n5. Average wind speed in best regions: 6.0–7.0 m/s",
Moldova: "1. Total turbines: ~25 (Onshore: ~25, Offshore: 0 — landlocked, no offshore potential)\n2. Annual production: ~0.05 billion kWh, covering ~1% of national electricity demand\n3. Wind energy revenue: ~€2–3 million/year\n4. Exports: No — Moldova imports a large portion of its electricity, mainly from Romania and Ukraine\n5. Average wind speed in best regions: 6.5–8.0 m/s",
Turkey: "1. Total turbines: ~3,800 (Onshore: ~3,700, Offshore: ~100 — pilot projects in Aegean Sea)\n2. Annual production: ~30 billion kWh, covering ~10–12% of national electricity demand\n3. Wind energy revenue: ~€2.5–3.5 billion/year\n4. Exports: Yes — Turkey exports electricity to neighboring countries, including wind-based surplus\n5. Average wind speed in best regions: 7.5–9.5 m/s",
Norway: "1. Total turbines: ~1,300 (Onshore: ~1,200, Offshore: ~100 — pilot floating offshore projects)\n2. Annual production: ~10 billion kWh, covering ~6–7% of national electricity demand\n3. Wind energy revenue: ~€800 million–1 billion/year\n4. Exports: Yes — Norway exports large amounts of electricity, mainly from hydro, but wind contributes to the surplus\n5. Average wind speed in best regions: 8.0–10.0 m/s",
Malta: "1. Total turbines: 0 (Onshore: 0, Offshore: 0 — no current wind installations)\n2. Annual production: 0 kWh from wind, 0% of national electricity demand\n3. Wind energy revenue: €0/year\n4. Exports: No — Malta imports electricity via submarine cable from Italy\n5. Average wind speed in best regions: 7.0–8.5 m/s",
Bulgaria: "1. Total turbines: ~300 (Onshore: ~300, Offshore: 0 — offshore projects in early planning stages)\n2. Annual production: ~1.2 billion kWh, covering ~3–4% of national electricity demand\n3. Wind energy revenue: ~€80–100 million/year\n4. Exports: Yes — Bulgaria exports electricity, especially to Greece, Serbia, and North Macedonia\n5. Average wind speed in best regions: 7.0–9.0 m/s"
     
 

};

// Модальное окно — показать информацию
function showInfo(country) {
  document.getElementById("countryTitle").innerText = country;
  document.getElementById("countryDetails").innerText = infoData[country];
  document.getElementById("infoModal").style.display = "block";
}

// Закрыть модалку
function closeModal() {
  document.getElementById("infoModal").style.display = "none";
}

// Клик вне модалки — закрыть
window.onclick = function(event) {
  const modal = document.getElementById("infoModal");
  if (event.target === modal) {
    closeModal();
  }
};


// Функция для создания зелёной кнопки на карте
function addCountryMarker(lat, lng, country, label) {
  const markerHtml = `
    <div class="map-button" onclick="showInfo('${country}')">
      ${label}
    </div>
  `;

  const icon = L.divIcon({
    className: 'custom-div-icon',
    html: markerHtml,
    iconSize: [100, 30],
    iconAnchor: [50, 15]
  });

  L.marker([lat, lng], { icon }).addTo(map);
}
addCountryMarker(41.3, 19.8, 'Albania', '🇦🇱 Albania');
addCountryMarker(47.5, 14.5, 'Austria', '🇦🇹 Austria');
addCountryMarker(50.5, 4.5, 'Belgium', '🇧🇪 Belgium');
addCountryMarker(43.2, 17.7, 'Bosnia and Herzegovina', '🇧🇦 Bosnia');
addCountryMarker(42.7, 25.5, 'Bulgaria', '🇧🇬 Bulgaria');
addCountryMarker(45.2, 15.2, 'Croatia', '🇭🇷 Croatia');
addCountryMarker(49.8, 15.5, 'Czech Republic', '🇨🇿 Czechia');
addCountryMarker(55.7, 12.6, 'Denmark', '🇩🇰 Denmark');
addCountryMarker(59.4, 24.7, 'Estonia', '🇪🇪 Estonia');
addCountryMarker(60.2, 24.9, 'Finland', '🇫🇮 Finland');
addCountryMarker(48.8, 2.3, 'France', '🇫🇷 France');
addCountryMarker(42.0, 43.6, 'Georgia', '🇬🇪 Georgia');
addCountryMarker(51.2, 10.4, 'Germany', '🇩🇪 Germany');
addCountryMarker(39.0, 22.9, 'Greece', '🇬🇷 Greece');
addCountryMarker(47.2, 19.1, 'Hungary', '🇭🇺 Hungary');
addCountryMarker(64.1, -21.9, 'Iceland', '🇮🇸 Iceland');
addCountryMarker(53.3, -6.2, 'Ireland', '🇮🇪 Ireland');
addCountryMarker(41.9, 12.5, 'Italy', '🇮🇹 Italy');
addCountryMarker(56.9, 24.1, 'Latvia', '🇱🇻 Latvia');
addCountryMarker(54.7, 25.3, 'Lithuania', '🇱🇹 Lithuania');
addCountryMarker(49.6, 6.1, 'Luxembourg', '🇱🇺 Luxembourg');
addCountryMarker(41.6, 21.7, 'North Macedonia', '🇲🇰 North Macedonia');
addCountryMarker(42.0, 19.3, 'Montenegro', '🇲🇪 Montenegro');
addCountryMarker(52.2, 21.0, 'Poland', '🇵🇱 Poland');
addCountryMarker(38.7, -9.1, 'Portugal', '🇵🇹 Portugal');
addCountryMarker(46.0, 25.0, 'Romania', '🇷🇴 Romania');
addCountryMarker(55.1, 37.6, 'Russia', '🇷🇺 Russia');
addCountryMarker(43.9, 12.4, 'San Marino', '🇸🇲 San Marino');
addCountryMarker(44.0, 21.0, 'Serbia', '🇷🇸 Serbia');
addCountryMarker(48.1, 17.1, 'Slovakia', '🇸🇰 Slovakia');
addCountryMarker(46.1, 14.5, 'Slovenia', '🇸🇮 Slovenia');
addCountryMarker(40.4, -3.7, 'Spain', '🇪🇸 Spain');
addCountryMarker(59.3, 18.0, 'Sweden', '🇸🇪 Sweden');
addCountryMarker(46.9, 7.4, 'Switzerland', '🇨🇭 Switzerland');
addCountryMarker(35.2, 33.4, 'Cyprus', '🇨🇾 Cyprus');
addCountryMarker(50.4, 30.5, 'Ukraine', '🇺🇦 Ukraine');
addCountryMarker(55.4, -3.4, 'United Kingdom', '🇬🇧 UK');
addCountryMarker(42.5, 1.5, 'Andorra', '🇦🇩 Andorra');
addCountryMarker(40.1, 44.5, 'Armenia', '🇦🇲 Armenia');
addCountryMarker(47.1416, 9.5215, 'Liechtenstein', '🇱🇮 Liechtenstein');
addCountryMarker(42.7, 19.3, 'Kosovo', '🇽🇰 Kosovo');
addCountryMarker(43.7384, 7.4246, 'Monaco', '🇲🇨 Monaco');
addCountryMarker(47.0, 28.8, 'Moldova', '🇲🇩 Moldova');
addCountryMarker(52.3, 4.9, 'Netherlands', '🇳🇱 Netherlands');
addCountryMarker(39.0, 35.0, 'Turkey', '🇹🇷 Turkey');         
addCountryMarker(60.5, 8.5, 'Norway', '🇳🇴 Norway');        
addCountryMarker(35.9, 14.5, 'Malta', '🇲🇹 Malta');          

windData = [
{ country: "Spain", turbines: 21500, production: 63.0, revenue: 5.0, exports: 10.0, speed: 7.5 },
{ country: "France", turbines: 9400, production: 42.0, revenue: 3.0, exports: 15.0, speed: 7.0 },
{ country: "Sweden", turbines: 4900, production: 33.0, revenue: 2.0, exports: 25.0, speed: 7.5 },
{ country: "Poland", turbines: 1400, production: 17.0, revenue: 1.2, exports: 1.0, speed: 7.0 },
{ country: "Albania", turbines: 90, production: 0.2, revenue: 0.01, exports: 0.0, speed: 6.5 },
{ country: "Austria", turbines: 1400, production: 3.5, revenue: 0.3, exports: 0.2, speed: 6.5 },
{ country: "Belgium", turbines: 1800, production: 11.0, revenue: 0.8, exports: 1.0, speed: 7.5 },
{ country: "Bosnia and Herzegovina", turbines: 80, production: 0.15, revenue: 0.008, exports: 0.0, speed: 6.5 },
{ country: "Croatia", turbines: 200, production: 0.5, revenue: 0.03, exports: 0.02, speed: 7.0 },
{ country: "Czech Republic", turbines: 200, production: 0.3, revenue: 0.02, exports: 0.01, speed: 6.0 },
{ country: "Estonia", turbines: 130, production: 0.4, revenue: 0.025, exports: 0.01, speed: 7.5 },
{ country: "Finland", turbines: 1500, production: 12.0, revenue: 0.9, exports: 0.5, speed: 7.0 },
{ country: "Georgia", turbines: 20, production: 0.05, revenue: 0.004, exports: 0.01, speed: 6.5 },
{ country: "Greece", turbines: 2800, production: 9.0, revenue: 0.6, exports: 0.2, speed: 7.5 },
{ country: "Hungary", turbines: 170, production: 0.25, revenue: 0.015, exports: 0.01, speed: 6.0 },
{ country: "Iceland", turbines: 10, production: 0.02, revenue: 0.001, exports: 0.0, speed: 9.0 },
{ country: "Ireland", turbines: 2000, production: 10.0, revenue: 0.8, exports: 0.5, speed: 8.5 },
{ country: "Italy", turbines: 1250, production: 20.0, revenue: 1.5, exports: 0.5, speed: 6.5 },
{ country: "Latvia", turbines: 120, production: 0.2, revenue: 0.01, exports: 0.01, speed: 7.0 },
{ country: "Lithuania", turbines: 170, production: 0.5, revenue: 0.03, exports: 0.02, speed: 7.0 },
{ country: "Luxembourg", turbines: 70, production: 0.15, revenue: 0.008, exports: 0.0, speed: 6.5 },
{ country: "North Macedonia", turbines: 40, production: 0.07, revenue: 0.004, exports: 0.0, speed: 6.5 },
{ country: "Montenegro", turbines: 40, production: 0.1, revenue: 0.005, exports: 0.01, speed: 6.5 },
{ country: "Portugal", turbines: 2800, production: 15.0, revenue: 1.2, exports: 1.0, speed: 7.5 },
{ country: "Romania", turbines: 1200, production: 7.0, revenue: 0.5, exports: 0.5, speed: 7.5 },
{ country: "Russia", turbines: 250, production: 0.5, revenue: 0.03, exports: 0.0, speed: 7.5 },
{ country: "San Marino", turbines: 0, production: 0.0, revenue: 0.0, exports: 0.0, speed: 6.0 },
{ country: "Serbia", turbines: 100, production: 0.3, revenue: 0.02, exports: 0.01, speed: 6.5 },
{ country: "Slovakia", turbines: 5, production: 0.01, revenue: 0.001, exports: 0.0, speed: 6.0 },
{ country: "Slovenia", turbines: 2, production: 0.005, revenue: 0.0002, exports: 0.0, speed: 6.5 },
{ country: "Switzerland", turbines: 40, production: 0.1, revenue: 0.005, exports: 0.0, speed: 6.5 },
{ country: "Cyprus", turbines: 40, production: 0.25, revenue: 0.015, exports: 0.0, speed: 7.0 },
{ country: "Ukraine", turbines: 750, production: 2.5, revenue: 0.15, exports: 0.1, speed: 7.5 },
{ country: "Andorra", turbines: 0, production: 0.0, revenue: 0.0, exports: 0.0, speed: 6.0 },
{ country: "Armenia", turbines: 5, production: 0.01, revenue: 0.001, exports: 0.01, speed: 6.5 },
{ country: "Liechtenstein", turbines: 0, production: 0.0, revenue: 0.0, exports: 0.0, speed: 6.0 },
{ country: "Kosovo", turbines: 30, production: 0.05, revenue: 0.002, exports: 0.0, speed: 6.5 },
{ country: "Monaco", turbines: 0, production: 0.0, revenue: 0.0, exports: 0.0, speed: 6.0 },
{ country: "Moldova", turbines: 25, production: 0.05, revenue: 0.002, exports: 0.0, speed: 6.5 },
{ country: "Turkey", turbines: 3800, production: 30.0, revenue: 2.5, exports: 1.0, speed: 7.5 },
{ country: "Norway", turbines: 1300, production: 10.0, revenue: 0.8, exports: 1.0, speed: 8.0 },
{ country: "Malta", turbines: 0, production: 0.0, revenue: 0.0, exports: 0.0, speed: 7.0 },
{ country: "Bulgaria", turbines: 300, production: 1.2, revenue: 0.08, exports: 0.1, speed: 7.0 },
{ country: "United Kingdom", turbines: 11500, production: 85.0, revenue: 9.0, exports: 20.0, speed: 9.0 },
{ country: "Germany", turbines: 28500, production: 139.0, revenue: 12.0, exports: 60.0, speed: 8.5 },
{ country: "Denmark", turbines: 6700, production: 45.0, revenue: 3.5, exports: 10.0, speed: 8.5 },
{ country: "Netherlands", turbines: 3200, production: 28.0, revenue: 2.5, exports: 5.0, speed: 8.0 }

// график вопрос 1


];

function updateChart(metric) {
  const labels = {
    turbines: "Total Turbines",
    production: "Annual Production (billion kWh)",
    revenue: "Wind Revenue (€B)",
    exports: "Exports (TWh)",
    speed: "Wind Speed (m/s)"
  };

  const trace = {
    type: "bar",
    x: windData.map(item => item.country),
    y: windData.map(item => item[metric]),
    marker: { color: '#28a745' }
  };

  const layout = {
    title: labels[metric],
    xaxis: { title: "", tickangle: -45 },
    yaxis: { title: labels[metric] },
    margin: { l: 60, r: 30, t: 60, b: 120 },
    height: 600
  };

  Plotly.newPlot("barChart", [trace], layout, {responsive: true});
}

updateChart('turbines');



// график вопрос 2
let chartInstance;

function showChart(type) {
  const ctx = document.getElementById("windTurbineChart").getContext("2d");
  if (chartInstance) chartInstance.destroy();

  const labels = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024];

  const datasets = {
    turbines: [
      {
        label: 'Germany',
        data: [28500, 29497, 30530, 31598, 32704, 33849, 35034, 36260, 37529, 38843],
        borderColor: 'rgba(138, 128, 117, 1)',
        backgroundColor: 'rgba(138, 128, 117, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Spain',
        data: [21500, 22252, 23031, 23837, 24672, 25535, 26429, 27354, 28311, 29302],
        borderColor: 'rgba(156, 142, 61, 1)',
        backgroundColor: 'rgba(156, 142, 61, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'United Kingdom',
        data: [11500, 11902, 12319, 12750, 13197, 13658, 14136, 14631, 15143, 15673],
        borderColor: 'rgba(218, 157, 61, 1)',
        backgroundColor: 'rgba(218, 157, 61, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'France',
        data: [9400, 9729, 10070, 10422, 10787, 11164, 11555, 11959, 12378, 12811],
        borderColor: 'rgba(75, 209, 198, 1)',
        backgroundColor: 'rgba(75, 209, 198, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Denmark',
        data: [6700, 6934, 7177, 7428, 7688, 7957, 8236, 8524, 8823, 9131],
        borderColor: 'rgba(206, 203, 108, 1)',
        backgroundColor: 'rgba(206, 203, 108, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Sweden',
        data: [4900, 5072, 5249, 5433, 5623, 5820, 6023, 6234, 6452, 6678],
        borderColor: 'rgba(204, 172, 111, 1)',
        backgroundColor: 'rgba(204, 172, 111, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Turkey',
        data: [3800, 3933, 4071, 4213, 4361, 4513, 4671, 4835, 5004, 5179],
        borderColor: 'rgba(116, 172, 181, 1)',
        backgroundColor: 'rgba(116, 172, 181, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Netherlands',
        data: [3200, 3312, 3428, 3548, 3672, 3801, 3934, 4071, 4214, 4361],
        borderColor: 'rgba(238, 103, 78, 1)',
        backgroundColor: 'rgba(238, 103, 78, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Portugal',
        data: [2800, 2898, 2999, 3104, 3213, 3326, 3442, 3562, 3687, 3816],
        borderColor: 'rgba(119, 69, 95, 1)',
        backgroundColor: 'rgba(119, 69, 95, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Greece',
        data: [2800, 2898, 2999, 3104, 3213, 3326, 3442, 3562, 3687, 3816],
        borderColor: 'rgba(71, 143, 116, 1)',
        backgroundColor: 'rgba(71, 143, 116, 0.5)',
        fill: false,
        tension: 0.3
      }
    ],
    production: [
      {
        label: 'Germany',
        data: [89.0, 92.6, 96.3, 100.1, 104.1, 108.2, 112.5, 116.9, 121.5, 126.3],
        borderColor: 'rgba(138, 128, 117, 1)',
        backgroundColor: 'rgba(138, 128, 117, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Spain',
        data: [63.0, 65.52, 68.14, 70.87, 73.7, 76.65, 79.72, 82.9, 86.22, 89.67],
        borderColor: 'rgba(156, 142, 61, 1)',
        backgroundColor: 'rgba(156, 142, 61, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'United Kingdom',
        data: [34.5, 36.02, 37.57, 39.17, 40.82, 42.51, 44.26, 46.05, 47.9, 49.8],
        borderColor: 'rgba(218, 157, 61, 1)',
        backgroundColor: 'rgba(218, 157, 61, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'France',
        data: [42.0, 43.68, 45.43, 47.24, 49.13, 51.1, 53.14, 55.27, 57.48, 59.78],
        borderColor: 'rgba(75, 209, 198, 1)',
        backgroundColor: 'rgba(75, 209, 198, 0.5)',
        fill: false,
        tension: 0.3
      }, {
        label: 'Denmark',
        data: [29.0, 30.16, 31.37, 32.62, 33.93, 35.29, 36.7, 38.17, 39.7, 41.29],
        borderColor: 'rgba(206, 203, 108, 1)',
        backgroundColor: 'rgba(206, 203, 108, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Sweden',
        data: [33.0, 34.32, 35.69, 37.12, 38.61, 40.15, 41.76, 43.43, 45.16, 46.97],
        borderColor: 'rgba(204, 172, 111, 1)',
        backgroundColor: 'rgba(204, 172, 111, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Turkey',
        data: [22.0, 22.88, 23.79, 24.74, 25.73, 26.76, 27.83, 28.94, 30.09, 31.28],
        borderColor: 'rgba(116, 172, 181, 1)',
        backgroundColor: 'rgba(116, 172, 181, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Netherlands',
        data: [19.0, 19.72, 20.46, 21.24, 22.04, 22.88, 23.74, 24.63, 25.55, 26.5],
        borderColor: 'rgba(238, 103, 78, 1)',
        backgroundColor: 'rgba(238, 103, 78, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Portugal',
        data: [17.0, 17.68, 18.38, 19.12, 19.88, 20.67, 21.49, 22.33, 23.2, 24.09],
        borderColor: 'rgba(119, 69, 95, 1)',
        backgroundColor: 'rgba(119, 69, 95, 0.5)',
        fill: false,
        tension: 0.3
      },
      {
        label: 'Greece',
        data: [17.0, 17.68, 18.38, 19.12, 19.88, 20.67, 21.49, 22.33, 23.2, 24.09],
        borderColor: 'rgba(71, 143, 116, 1)',
        backgroundColor: 'rgba(71, 143, 116, 0.5)',
        fill: false,
        tension: 0.3
      }
    ],
     turbines_full:  [
  {
    "label": "Albania",
    "data": [
      90,
      93,
      96,
      100,
      103,
      107,
      111,
      115,
      119,
      123
    ],
    "borderColor": "hsl(0, 70%, 45%)",
    "backgroundColor": "hsl(0, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Andorra",
    "data": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    "borderColor": "hsl(7, 70%, 45%)",
    "backgroundColor": "hsl(7, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Armenia",
    "data": [
      5,
      5,
      5,
      6,
      6,
      6,
      6,
      6,
      7,
      7
    ],
    "borderColor": "hsl(15, 70%, 45%)",
    "backgroundColor": "hsl(15, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Austria",
    "data": [
      1400,
      1449,
      1500,
      1552,
      1607,
      1663,
      1721,
      1781,
      1844,
      1908
    ],
    "borderColor": "hsl(22, 70%, 45%)",
    "backgroundColor": "hsl(22, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Belgium",
    "data": [
      1800,
      1863,
      1928,
      1996,
      2066,
      2138,
      2213,
      2290,
      2370,
      2453
    ],
    "borderColor": "hsl(30, 70%, 45%)",
    "backgroundColor": "hsl(30, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Bosnia and Herzegovina",
    "data": [
      80,
      83,
      86,
      89,
      92,
      95,
      98,
      102,
      105,
      109
    ],
    "borderColor": "hsl(38, 70%, 45%)",
    "backgroundColor": "hsl(38, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Bulgaria",
    "data": [
      300,
      310,
      321,
      333,
      344,
      356,
      369,
      382,
      395,
      409
    ],
    "borderColor": "hsl(45, 70%, 45%)",
    "backgroundColor": "hsl(45, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Croatia",
    "data": [
      200,
      207,
      214,
      222,
      230,
      238,
      246,
      254,
      263,
      273
    ],
    "borderColor": "hsl(53, 70%, 45%)",
    "backgroundColor": "hsl(53, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Cyprus",
    "data": [
      40,
      41,
      43,
      44,
      46,
      48,
      49,
      51,
      53,
      55
    ],
    "borderColor": "hsl(61, 70%, 45%)",
    "backgroundColor": "hsl(61, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Czech Republic",
    "data": [
      200,
      207,
      214,
      222,
      230,
      238,
      246,
      254,
      263,
      273
    ],
    "borderColor": "hsl(68, 70%, 45%)",
    "backgroundColor": "hsl(68, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Denmark",
    "data": [
      6700,
      6934,
      7177,
      7428,
      7688,
      7957,
      8236,
      8524,
      8823,
      9131
    ],
    "borderColor": "hsl(76, 70%, 45%)",
    "backgroundColor": "hsl(76, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Estonia",
    "data": [
      130,
      135,
      139,
      144,
      149,
      154,
      160,
      165,
      171,
      177
    ],
    "borderColor": "hsl(84, 70%, 45%)",
    "backgroundColor": "hsl(84, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Finland",
    "data": [
      1500,
      1552,
      1607,
      1663,
      1721,
      1782,
      1844,
      1908,
      1975,
      2044
    ],
    "borderColor": "hsl(91, 70%, 45%)",
    "backgroundColor": "hsl(91, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "France",
    "data": [
      9400,
      9729,
      10070,
      10422,
      10787,
      11164,
      11555,
      11959,
      12378,
      12811
    ],
    "borderColor": "hsl(99, 70%, 45%)",
    "backgroundColor": "hsl(99, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Georgia",
    "data": [
      20,
      21,
      21,
      22,
      23,
      24,
      25,
      25,
      26,
      27
    ],
    "borderColor": "hsl(107, 70%, 45%)",
    "backgroundColor": "hsl(107, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Germany",
    "data": [
      28500,
      29497,
      30530,
      31598,
      32704,
      33849,
      35034,
      36260,
      37529,
      38843
    ],
    "borderColor": "hsl(114, 70%, 45%)",
    "backgroundColor": "hsl(114, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Greece",
    "data": [
      2800,
      2898,
      2999,
      3104,
      3213,
      3326,
      3442,
      3562,
      3687,
      3816
    ],
    "borderColor": "hsl(122, 70%, 45%)",
    "backgroundColor": "hsl(122, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Hungary",
    "data": [
      170,
      176,
      182,
      188,
      195,
      202,
      209,
      216,
      224,
      232
    ],
    "borderColor": "hsl(130, 70%, 45%)",
    "backgroundColor": "hsl(130, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Iceland",
    "data": [
      10,
      10,
      11,
      11,
      11,
      12,
      12,
      13,
      13,
      14
    ],
    "borderColor": "hsl(137, 70%, 45%)",
    "backgroundColor": "hsl(137, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Ireland",
    "data": [
      2000,
      2070,
      2142,
      2217,
      2295,
      2375,
      2459,
      2545,
      2634,
      2726
    ],
    "borderColor": "hsl(145, 70%, 45%)",
    "backgroundColor": "hsl(145, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Italy",
    "data": [
      1250,
      1294,
      1339,
      1386,
      1434,
      1485,
      1537,
      1590,
      1646,
      1704
    ],
    "borderColor": "hsl(153, 70%, 45%)",
    "backgroundColor": "hsl(153, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Kosovo",
    "data": [
      30,
      31,
      32,
      33,
      34,
      36,
      37,
      38,
      40,
      41
    ],
    "borderColor": "hsl(160, 70%, 45%)",
    "backgroundColor": "hsl(160, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Latvia",
    "data": [
      120,
      124,
      129,
      133,
      138,
      143,
      148,
      153,
      158,
      164
    ],
    "borderColor": "hsl(168, 70%, 45%)",
    "backgroundColor": "hsl(168, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Liechtenstein",
    "data": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    "borderColor": "hsl(176, 70%, 45%)",
    "backgroundColor": "hsl(176, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Lithuania",
    "data": [
      170,
      176,
      182,
      188,
      195,
      202,
      209,
      216,
      224,
      232
    ],
    "borderColor": "hsl(183, 70%, 45%)",
    "backgroundColor": "hsl(183, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Luxembourg",
    "data": [
      70,
      72,
      75,
      78,
      80,
      83,
      86,
      89,
      92,
      95
    ],
    "borderColor": "hsl(191, 70%, 45%)",
    "backgroundColor": "hsl(191, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Malta",
    "data": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    "borderColor": "hsl(199, 70%, 45%)",
    "backgroundColor": "hsl(199, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Moldova",
    "data": [
      25,
      26,
      27,
      28,
      29,
      30,
      31,
      32,
      33,
      34
    ],
    "borderColor": "hsl(206, 70%, 45%)",
    "backgroundColor": "hsl(206, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Monaco",
    "data": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    "borderColor": "hsl(214, 70%, 45%)",
    "backgroundColor": "hsl(214, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Montenegro",
    "data": [
      40,
      41,
      43,
      44,
      46,
      48,
      49,
      51,
      53,
      55
    ],
    "borderColor": "hsl(222, 70%, 45%)",
    "backgroundColor": "hsl(222, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Netherlands",
    "data": [
      3200,
      3312,
      3428,
      3548,
      3672,
      3801,
      3934,
      4071,
      4214,
      4361
    ],
    "borderColor": "hsl(229, 70%, 45%)",
    "backgroundColor": "hsl(229, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "North Macedonia",
    "data": [
      40,
      41,
      43,
      44,
      46,
      48,
      49,
      51,
      53,
      55
    ],
    "borderColor": "hsl(237, 70%, 45%)",
    "backgroundColor": "hsl(237, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Norway",
    "data": [
      1300,
      1346,
      1393,
      1441,
      1492,
      1544,
      1598,
      1654,
      1712,
      1772
    ],
    "borderColor": "hsl(245, 70%, 45%)",
    "backgroundColor": "hsl(245, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Poland",
    "data": [
      1400,
      1449,
      1500,
      1552,
      1607,
      1663,
      1721,
      1781,
      1844,
      1908
    ],
    "borderColor": "hsl(252, 70%, 45%)",
    "backgroundColor": "hsl(252, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Portugal",
    "data": [
      2800,
      2898,
      2999,
      3104,
      3213,
      3326,
      3442,
      3562,
      3687,
      3816
    ],
    "borderColor": "hsl(260, 70%, 45%)",
    "backgroundColor": "hsl(260, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Romania",
    "data": [
      1200,
      1242,
      1285,
      1330,
      1377,
      1425,
      1475,
      1527,
      1580,
      1635
    ],
    "borderColor": "hsl(268, 70%, 45%)",
    "backgroundColor": "hsl(268, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Russia",
    "data": [
      250,
      259,
      268,
      277,
      287,
      297,
      307,
      318,
      329,
      341
    ],
    "borderColor": "hsl(275, 70%, 45%)",
    "backgroundColor": "hsl(275, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "San Marino",
    "data": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ],
    "borderColor": "hsl(283, 70%, 45%)",
    "backgroundColor": "hsl(283, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Serbia",
    "data": [
      100,
      103,
      107,
      111,
      115,
      119,
      123,
      127,
      132,
      136
    ],
    "borderColor": "hsl(291, 70%, 45%)",
    "backgroundColor": "hsl(291, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Slovakia",
    "data": [
      5,
      5,
      5,
      6,
      6,
      6,
      6,
      6,
      7,
      7
    ],
    "borderColor": "hsl(298, 70%, 45%)",
    "backgroundColor": "hsl(298, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Slovenia",
    "data": [
      2,
      2,
      2,
      2,
      2,
      2,
      2,
      3,
      3,
      3
    ],
    "borderColor": "hsl(306, 70%, 45%)",
    "backgroundColor": "hsl(306, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Spain",
    "data": [
      21500,
      22252,
      23031,
      23837,
      24672,
      25535,
      26429,
      27354,
      28311,
      29302
    ],
    "borderColor": "hsl(314, 70%, 45%)",
    "backgroundColor": "hsl(314, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Sweden",
    "data": [
      4900,
      5072,
      5249,
      5433,
      5623,
      5820,
      6023,
      6234,
      6452,
      6678
    ],
    "borderColor": "hsl(321, 70%, 45%)",
    "backgroundColor": "hsl(321, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Switzerland",
    "data": [
      40,
      41,
      43,
      44,
      46,
      48,
      49,
      51,
      53,
      55
    ],
    "borderColor": "hsl(329, 70%, 45%)",
    "backgroundColor": "hsl(329, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Turkey",
    "data": [
      3800,
      3933,
      4071,
      4213,
      4361,
      4513,
      4671,
      4835,
      5004,
      5179
    ],
    "borderColor": "hsl(337, 70%, 45%)",
    "backgroundColor": "hsl(337, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "Ukraine",
    "data": [
      750,
      776,
      803,
      832,
      861,
      891,
      922,
      954,
      988,
      1022
    ],
    "borderColor": "hsl(344, 70%, 45%)",
    "backgroundColor": "hsl(344, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  },
  {
    "label": "United Kingdom",
    "data": [
      11500,
      11902,
      12319,
      12750,
      13197,
      13658,
      14136,
      14631,
      15143,
      15673
    ],
    "borderColor": "hsl(352, 70%, 45%)",
    "backgroundColor": "hsl(352, 70%, 65%)",
    "fill": false,
    "tension": 0.3
  }
],
     production_full: [
       {
  label: "Albania",
  data: [0.2, 0.21, 0.22, 0.22, 0.23, 0.24, 0.25, 0.26, 0.27, 0.28],
  borderColor: "hsl(0, 70%, 45%)",
  backgroundColor: "hsl(0, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Andorra",
  data: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
  borderColor: "hsl(7, 70%, 45%)",
  backgroundColor: "hsl(7, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Armenia",
  data: [0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01],
  borderColor: "hsl(15, 70%, 45%)",
  backgroundColor: "hsl(15, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Austria",
  data: [3.5, 3.64, 3.79, 3.94, 4.09, 4.26, 4.43, 4.61, 4.79, 4.98],
  borderColor: "hsl(22, 70%, 45%)",
  backgroundColor: "hsl(22, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Belgium",
  data: [11.0, 11.44, 11.9, 12.37, 12.87, 13.38, 13.92, 14.48, 15.05, 15.66],
  borderColor: "hsl(30, 70%, 45%)",
  backgroundColor: "hsl(30, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Bosnia and Herzegovina",
  data: [0.15, 0.16, 0.16, 0.17, 0.18, 0.18, 0.19, 0.20, 0.21, 0.21],
  borderColor: "hsl(38, 70%, 45%)",
  backgroundColor: "hsl(38, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Bulgaria",
  data: [1.2, 1.25, 1.3, 1.35, 1.4, 1.46, 1.52, 1.58, 1.64, 1.71],
  borderColor: "hsl(45, 70%, 45%)",
  backgroundColor: "hsl(45, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Croatia",
  data: [0.5, 0.52, 0.54, 0.56, 0.58, 0.61, 0.63, 0.66, 0.68, 0.71],
  borderColor: "hsl(53, 70%, 45%)",
  backgroundColor: "hsl(53, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Cyprus",
  data: [0.25, 0.26, 0.27, 0.28, 0.29, 0.3, 0.32, 0.33, 0.34, 0.36],
  borderColor: "hsl(61, 70%, 45%)",
  backgroundColor: "hsl(61, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Czech Republic",
  data: [0.3, 0.31, 0.32, 0.34, 0.35, 0.36, 0.38, 0.39, 0.41, 0.43],
  borderColor: "hsl(68, 70%, 45%)",
  backgroundColor: "hsl(68, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Denmark",
  data: [45.0, 46.8, 48.67, 50.62, 52.64, 54.75, 56.94, 59.22, 61.59, 64.05],
  borderColor: "hsl(76, 70%, 45%)",
  backgroundColor: "hsl(76, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Estonia",
  data: [0.4, 0.42, 0.43, 0.45, 0.47, 0.49, 0.51, 0.53, 0.55, 0.57],
  borderColor: "hsl(84, 70%, 45%)",
  backgroundColor: "hsl(84, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Finland",
  data: [12.0, 12.48, 12.98, 13.5, 14.04, 14.6, 15.18, 15.79, 16.42, 17.08],
  borderColor: "hsl(91, 70%, 45%)",
  backgroundColor: "hsl(91, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "France",
  data: [42.0, 43.68, 45.43, 47.24, 49.13, 51.1, 53.14, 55.27, 57.48, 59.78],
  borderColor: "hsl(99, 70%, 45%)",
  backgroundColor: "hsl(99, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Georgia",
  data: [0.05, 0.05, 0.05, 0.06, 0.06, 0.06, 0.06, 0.07, 0.07, 0.07],
  borderColor: "hsl(107, 70%, 45%)",
  backgroundColor: "hsl(107, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Germany",
  data: [139.0, 144.56, 150.34, 156.36, 162.61, 169.11, 175.88, 182.91, 190.23, 197.84],
  borderColor: "hsl(114, 70%, 45%)",
  backgroundColor: "hsl(114, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Greece",
  data: [9.0, 9.36, 9.73, 10.12, 10.53, 10.95, 11.39, 11.84, 12.32, 12.81],
  borderColor: "hsl(122, 70%, 45%)",
  backgroundColor: "hsl(122, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Hungary",
  data: [0.25, 0.26, 0.27, 0.28, 0.29, 0.3, 0.32, 0.33, 0.34, 0.36],
  borderColor: "hsl(130, 70%, 45%)",
  backgroundColor: "hsl(130, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Iceland",
  data: [0.02, 0.02, 0.02, 0.02, 0.02, 0.02, 0.03, 0.03, 0.03, 0.03],
  borderColor: "hsl(137, 70%, 45%)",
  backgroundColor: "hsl(137, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Ireland",
  data: [10.0, 10.4, 10.82, 11.25, 11.7, 12.17, 12.65, 13.16, 13.69, 14.23],
  borderColor: "hsl(145, 70%, 45%)",
  backgroundColor: "hsl(145, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Italy",
  data: [20.0, 20.8, 21.63, 22.5, 23.4, 24.33, 25.31, 26.32, 27.37, 28.47],
  borderColor: "hsl(153, 70%, 45%)",
  backgroundColor: "hsl(153, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Kosovo",
  data: [0.05, 0.05, 0.05, 0.06, 0.06, 0.06, 0.06, 0.07, 0.07, 0.07],
  borderColor: "hsl(160, 70%, 45%)",
  backgroundColor: "hsl(160, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Latvia",
  data: [0.2, 0.21, 0.22, 0.22, 0.23, 0.24, 0.25, 0.26, 0.27, 0.28],
  borderColor: "hsl(168, 70%, 45%)",
  backgroundColor: "hsl(168, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Liechtenstein",
  data: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
  borderColor: "hsl(176, 70%, 45%)",
  backgroundColor: "hsl(176, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Lithuania",
  data: [0.5, 0.52, 0.54, 0.56, 0.58, 0.61, 0.63, 0.66, 0.68, 0.71],
  borderColor: "hsl(183, 70%, 45%)",
  backgroundColor: "hsl(183, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Luxembourg",
  data: [0.15, 0.16, 0.16, 0.17, 0.18, 0.18, 0.19, 0.2, 0.21, 0.21],
  borderColor: "hsl(191, 70%, 45%)",
  backgroundColor: "hsl(191, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Malta",
  data: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
  borderColor: "hsl(199, 70%, 45%)",
  backgroundColor: "hsl(199, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Moldova",
  data: [0.05, 0.05, 0.05, 0.06, 0.06, 0.06, 0.06, 0.07, 0.07, 0.07],
  borderColor: "hsl(206, 70%, 45%)",
  backgroundColor: "hsl(206, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Monaco",
  data: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
  borderColor: "hsl(214, 70%, 45%)",
  backgroundColor: "hsl(214, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Montenegro",
  data: [0.1, 0.1, 0.11, 0.11, 0.12, 0.12, 0.13, 0.13, 0.14, 0.14],
  borderColor: "hsl(222, 70%, 45%)",
  backgroundColor: "hsl(222, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Netherlands",
  data: [28.0, 29.12, 30.28, 31.5, 32.76, 34.07, 35.43, 36.85, 38.32, 39.85],
  borderColor: "hsl(229, 70%, 45%)",
  backgroundColor: "hsl(229, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "North Macedonia",
  data: [0.07, 0.07, 0.08, 0.08, 0.08, 0.09, 0.09, 0.09, 0.1, 0.1],
  borderColor: "hsl(237, 70%, 45%)",
  backgroundColor: "hsl(237, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Norway",
  data: [10.0, 10.4, 10.82, 11.25, 11.7, 12.17, 12.65, 13.16, 13.69, 14.23],
  borderColor: "hsl(245, 70%, 45%)",
  backgroundColor: "hsl(245, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Poland",
  data: [17.0, 17.68, 18.39, 19.12, 19.89, 20.68, 21.51, 22.37, 23.27, 24.2],
  borderColor: "hsl(252, 70%, 45%)",
  backgroundColor: "hsl(252, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Portugal",
  data: [15.0, 15.6, 16.22, 16.87, 17.55, 18.25, 18.98, 19.74, 20.53, 21.35],
  borderColor: "hsl(260, 70%, 45%)",
  backgroundColor: "hsl(260, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Romania",
  data: [7.0, 7.28, 7.57, 7.87, 8.19, 8.52, 8.86, 9.21, 9.58, 9.96],
  borderColor: "hsl(268, 70%, 45%)",
  backgroundColor: "hsl(268, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Russia",
  data: [0.5, 0.52, 0.54, 0.56, 0.58, 0.61, 0.63, 0.66, 0.68, 0.71],
  borderColor: "hsl(275, 70%, 45%)",
  backgroundColor: "hsl(275, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "San Marino",
  data: [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
  borderColor: "hsl(283, 70%, 45%)",
  backgroundColor: "hsl(283, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Serbia",
  data: [0.3, 0.31, 0.32, 0.34, 0.35, 0.36, 0.38, 0.39, 0.41, 0.43],
  borderColor: "hsl(291, 70%, 45%)",
  backgroundColor: "hsl(291, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Slovakia",
  data: [0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01],
  borderColor: "hsl(298, 70%, 45%)",
  backgroundColor: "hsl(298, 70%, 65%)",
  fill: false,
  tension: 0.3
},
       {
  label: "Slovenia",
  data: [0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01, 0.01],
  borderColor: "hsl(306, 70%, 45%)",
  backgroundColor: "hsl(306, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Spain",
  data: [63.0, 65.52, 68.14, 70.87, 73.7, 76.65, 79.72, 82.9, 86.22, 89.67],
  borderColor: "hsl(314, 70%, 45%)",
  backgroundColor: "hsl(314, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Sweden",
  data: [33.0, 34.32, 35.69, 37.12, 38.61, 40.15, 41.76, 43.43, 45.16, 46.97],
  borderColor: "hsl(321, 70%, 45%)",
  backgroundColor: "hsl(321, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Switzerland",
  data: [0.1, 0.1, 0.11, 0.11, 0.12, 0.12, 0.13, 0.13, 0.14, 0.14],
  borderColor: "hsl(329, 70%, 45%)",
  backgroundColor: "hsl(329, 70%, 65%)",
  fill: false,
  tension: 0.3
},
{
  label: "Turkey",
  data: [30.0, 31.2, 32.45, 33.75, 35.1, 36.5, 37.96, 39.48, 41.06, 42.7],
  borderColor: "hsl(337, 70%, 45%)",
  backgroundColor: "hsl(337, 70%, 65%)",
  fill: false,
  tension: 0.3
}
     ]
  };

  chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: datasets[type]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right'
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            text: 'Year'
          }
        },
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: type === 'production' ? 'Energy Production (TWh)' : 'Number of Wind Turbines'
          }
        }
      }
    }
  });
}

// Инициализация при загрузке
window.addEventListener('load', () => {
  showChart('turbines');
});

// 2 вертикального график 2 вопрос
const years = [2015,2016,2017,2018,2019,2020,2021,2022,2023,2024];
const co2Saved = [210, 225, 240, 260, 275, 290, 305, 320, 333, 345];
const fossilReduced = [38, 37.5, 36.8, 36, 35.2, 34, 32.5, 31, 29, 27.5];

new Chart(co2Chart, {
  type: 'bar',
  data: {
    labels: years,
    datasets: [{
      label: 'CO₂ Saved (Mt)',
      data: co2Saved,
      backgroundColor: 'orange'
    }]
  },
  options: {
    plugins: {
      title: {
        display: true,
        text: 'CO₂ Saved by Wind Energy'
      }
    }
  }
});

new Chart(fossilChart, {
  type: 'bar',
  data: {
    labels: years,
    datasets: [{
      label: 'Fossil Fuel Reduction (%)',
      data: fossilReduced,
      backgroundColor: 'gold'
    }]
  },
  options: {
    plugins: {
      title: {
        display: true,
        text: 'Reduction of Fossil Dependency'
      }
    }
  }
});

// дви вертикального график 3 вопрос
const ctx = document.getElementById("canvas").getContext("2d");

// Исходные данные
const countries = ["Germany", "Spain", "United Kingdom", "France", "Denmark", "Sweden", "Turkey", "Netherlands", "Portugal", "Greece"];
const data2024 = [38843, 29302, 15673, 12811, 9131, 6678, 5179, 4361, 3816, 3816];
const data2030 = [52438, 39557, 21158, 17294, 12326, 9015, 6991, 5887, 5151, 5151];

// Объединяем для перемешивания
let combined = countries.map((country, index) => ({
  country: country,
  val2024: data2024[index],
  val2030: data2030[index]
}));

// Перемешиваем
for (let i = combined.length - 1; i > 0; i--) {
  const j = Math.floor(Math.random() * (i + 1));
  [combined[i], combined[j]] = [combined[j], combined[i]];
}

// Разделяем обратно
let currentCountries = combined.map(item => item.country);
let currentData2024 = combined.map(item => item.val2024);
let currentData2030 = combined.map(item => item.val2030);

const data = {
  labels: currentCountries,
  datasets: [
    {
      label: '2024',
      data: currentData2024,
      backgroundColor: 'rgba(255, 255, 0, 0.9)'
    },
    {
      label: '2030',
      data: currentData2030,
      backgroundColor: 'rgba(40, 167, 69)'
    }
  ]
};

const config = {
  type: 'bar',
  data: data,
  options: {
    responsive: true,
    animation: {
      duration: 800,
      easing: 'easeOutQuart'
    },
    scales: {
      y: {
        beginAtZero: true,
        title: {
          display: true,
          text: 'Number of turbines',
          font: {
            size: 12
          },
          color: '#666'
        }
      }
    }
  }
};

const chart = new Chart(ctx, config);

// Циклическая прокрутка
setInterval(() => {
  const firstCountry = currentCountries.shift();
  const first2024 = currentData2024.shift();
  const first2030 = currentData2030.shift();

  currentCountries.push(firstCountry);
  currentData2024.push(first2024);
  currentData2030.push(first2030);

  data.labels = [...currentCountries];
  data.datasets[0].data = [...currentData2024];
  data.datasets[1].data = [...currentData2030];

  chart.update();
}, 3000);

// Bubble chart 3 вопрос

const windFarms2030 = [
  {
    name: "North Sea Giant",
    country: "Germany",
    launchYear: 2028,
    capacityMW: 3200,
    turbines: 180,
    investmentBillion: 5.2,
    color: "#1f77b4"
  },
  {
    name: "Atlantic Power Hub",
    country: "France",
    launchYear: 2029,
    capacityMW: 2500,
    turbines: 150,
    investmentBillion: 4.1,
    color: "#ff7f0e"
  },
  {
    name: "Baltic Wind Bridge",
    country: "Poland",
    launchYear: 2030,
    capacityMW: 2800,
    turbines: 160,
    investmentBillion: 4.5,
    color: "#2ca02c"
  },
  {
    name: "Mediterranean Breeze",
    country: "Spain",
    launchYear: 2027,
    capacityMW: 2200,
    turbines: 140,
    investmentBillion: 3.6,
    color: "#d62728"
  },
  {
    name: "Northern Lights Wind",
    country: "Sweden",
    launchYear: 2026,
    capacityMW: 2600,
    turbines: 170,
    investmentBillion: 3.9,
    color: "#9467bd"
  }
];


const bubbleData = [{
  x: windFarms2030.map(f => f.launchYear),
  y: windFarms2030.map(f => f.capacityMW),
  text: windFarms2030.map(f =>
    `<b>${f.name}</b><br>` +
    `Country: ${f.country}<br>` +
    `Launch Year: ${f.launchYear}<br>` +
    `Capacity: ${f.capacityMW} MW<br>` +
    `Turbines: ${f.turbines}<br>` +
    `Investment: €${f.investmentBillion}B`
  ),
  mode: 'markers',
  type: 'scatter',
  marker: {
    size: windFarms2030.map(f => f.investmentBillion * 10),
    color: windFarms2030.map(f => f.color),
    sizemode: 'area',
    sizeref: 2.0 * Math.max(...windFarms2030.map(f => f.investmentBillion)) / (100 ** 2),
    opacity: 0.75,
    line: {
      width: 2,
      color: '#ffffff'
    }
  },
  hovertemplate: '%{text}<extra></extra>'
}];

const bubbleLayout = {
  title: {
    text: "Future Wind Farms",
    font: {
      size: 24
    }
  },
  xaxis: {
    title: "Launch Year",
    tickformat: "d",
    gridcolor: "#eaeaea"
  },
  yaxis: {
    title: "Capacity (MW)",
    gridcolor: "#eaeaea"
  },
  margin: { t: 80, r: 40, l: 70, b: 70 },
  hovermode: "closest",
  plot_bgcolor: "#f9f9f9",
  paper_bgcolor: "#f9f9f9"
};

Plotly.newPlot('bubbleChart2030', bubbleData, bubbleLayout);




